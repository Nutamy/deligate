﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// A no argument event
/// </summary>
public class MessageEvent : UnityEvent
{
}
